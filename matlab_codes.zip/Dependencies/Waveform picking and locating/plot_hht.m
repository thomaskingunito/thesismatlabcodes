function [d,v,inst_amp,imf] = plot_hht(x,Ts)
% Plot the HHT.
% plot_hht(x,Ts)
% 
% :: Syntax
%    The array x is the input signal and Ts is the sampling period.
%    Example on use: [x,Fs] = wavread('Hum.wav');
%                    plot_hht(x(1:6000),1/Fs);
% Func : emd

% Get HHT.
imf = emd(x);

if size(imf,2) == 1
    d{1} = NaN;
    v = NaN;
    return
end
for k = 1:length(imf)
   b(k) = sum(imf{k}.*imf{k});
   inst_amp{k} = hilbert(imf{k});
   th   = angle(hilbert(imf{k}));
   d{k} = diff(th)/Ts/(2*pi);
end
[u,v] = sort(-b);
b = 1-b/max(b);

