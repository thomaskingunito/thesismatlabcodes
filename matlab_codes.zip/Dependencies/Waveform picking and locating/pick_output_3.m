%% Automated waveform picking
% This code picks the input waveform. Input data are simulated and an
% output model (yp) is produced. Signal onset is determined from this
% output.

%% Simulate model
yp = sim(dtdnn_net,p1);
yp = cell2mat(yp);
yp = smooth(yp,round(sigsamp/40)); % Smooth model output

%% Set picking limits for training or location code
if o ~= 0
    rayt = [Ts:Ts:(sigsamp*Ts)];
end
if o > 1
    adj =  round(pk{ordersize(1),2}/Ts);
    if isnan(adj) == 0
        test = 'adj:adj+round(sigsamp/5.5)';
        test2 = 'adj';
    else
        test = 'minpick:(length(yp))';
        test2 = 'minpick';
    end
else
    test = 'minpick:(length(yp))';
    test2 = 'minpick';
end

%% Determine window around transition between signal and noise
if max(yp(eval(test))) > 0
    lim = 0.8; fstp = 0;
    while fstp == 0
        try
            ind = find(yp(eval(test)-1) > ...
                lim*max(yp(eval(test)-1)) & ...
                yp(eval(test)-1) < 1.5)+eval(test2);
            try
                ind = ind(ind < length(sig)); ind = ind(1);
            catch
                ind = ind(ind < sigtest); ind = ind(1);
            end
            fstp = 1;
        catch
            lim = lim-0.1;
            if lim <= 0
                fstp = 2;
                break
            end
            fstp = 0;
            continue
        end
    end
    if fstp == 2
        pot
    end
else
    ind = diff([0.8*max(yp(eval(test)-1)),max(yp(eval(test)-1))]);
    ind = find(yp(eval(test)-1) > max(yp(eval(test)-1))+ind)+eval(test2);
    ind = ind(ind < length(sig)); ind = ind(1);
end

ind = find(yp(eval(test2):ind) < mean([yp(ind) min(yp(eval(test2):ind))]))+eval(test2);

% if isempty(ind)
%     display('error')
%     return
% end

%% Picks highest signal to noise ratio
snnew = [];
for p = ind(end)-200:length(ind)
    try
        snnew(p) = rms(sig(ind(p):ind(p)+100))/rms(sig(ind(p)-100:ind(p)));
    end
end

try
    indbck = ind;
    ind = ind(find(snnew == max(snnew)));
    pick = ind(end);
catch
    ind = indbck;
    ind = find(abs(yp(ind)) == min(abs(yp(ind)))) + ind(1);
    pick = ind(1);
end
