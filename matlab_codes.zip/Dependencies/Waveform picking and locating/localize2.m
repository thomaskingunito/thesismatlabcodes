%% Source location inversion
% Modified from Taddese, Biniyam Tesfaye, "Sound Source Localization and
% Separation" (2006). Mathematics, Statistics, and Computer Science Honors
% Projects. Paper 3.

function [answer, res] = localize2(simu, source, TOA,recloc,cvel,angles)
% Deterimine TDOA input data

% Reset
global cvel1
global micangle
cvel1 = cvel;
Guess = source;

% Time difference of arrival
indTOA = 0;
TDOA = [];
for r = 1:size(TOA,1)
    for s = 1:size(TOA,1)
        if r == s
            continue
        elseif indTOA > 1 && ismember([s,r],TDOA(:,[2,3]),'rows') == 1
            continue
        end
        indTOA = indTOA + 1;
        TDOA(indTOA,1) = TOA(r) - TOA(s);
        TDOA(indTOA,2) = r;
        TDOA(indTOA,3) = s;
        TDOA(indTOA,4) = TDOA(indTOA,1);
    end
end
TDOA = TDOA(isnan(TDOA(:,4)) == 0,:);
TDOA = sortrows(sortrows(TDOA,3),2);
MicLoc = recloc(unique(TDOA(:,2:3)),:);
micangle = angles(unique(TDOA(:,2:3)),unique(TDOA(:,2:3)));
delays = TDOA(:,4);

global BUSHMicLoc;
global BUSHDelays;

BUSHMicLoc = MicLoc;
BUSHDelays = delays;

options = optimset('MaxFunEvals',1000);

[answer,res] = fminsearch(@ellipseMerit, Guess, options);

function answer = distance(a, b)
% implements the Euclidean distance formula to find
% the distance b/n the two points given.
if(length(a)~=length(b))
    error('Dimensions do not match!');
end
answer = sqrt(sum((a-b).^2));

function answer = ellipseMerit(s)
% s -> the estimated source location. vec is the residual
global BUSHMicLoc;
global BUSHDelays;
vec = ellipseFun(s, BUSHMicLoc, BUSHDelays);
answer = sum(vec.^2); % Sum of least squares
global calcdelays
calcdelays = vec;

function [res] = ellipseFun(s, m, delays)
% s -> sound source position. [x y z]
% m -> receiver positions. (known)
% delays -> TDOA

% Calculate number of microphones and pairs
nMic = size(m, 1);
nPairs = (nMic.^2 - nMic)./2;
res = zeros(nPairs,1);
vel = zeros(nPairs,1);

% Set current velocity and anistropy
global cvel1
global micangle
c = cvel1(:,3);
Dis = zeros(nPairs,1);
vel = Dis;
h = 1;
vanis = cvel1(:,4);

% Calculate hypocentral distance and velocity
for k = 1:nMic
    for j = k+1:nMic
        % Travel distance
        diffD = distance(s, m(k,:)) - distance(s, m(j,:));
        Dis(h) = diffD;
       
        % Velocity anisotropy needs to better implemented
        vel(h) = ((c+(c*vanis))/2) - ...
            ((c-(c*vanis))/2)*...
            cos(pi-2*abs(deg2rad(micangle(k,j))));
        h = h+1;
    end
end

% Calculate residuals

for l=1:nPairs
for k=1:nPairs
    
   % res(l,k)= delays(l) - delays(k) - (Dis(l)./max(vel)) + (Dis(k)./max(vel));
    
    res(k)= Dis(k)./(max(vel)) - delays(k);
end
end

assignin('base','vel',vel)