%% Generate model input data
% Calculates signal entropy, signal envelope and instanstaneous frequency
% content of each waveform

%% Instaneous frequency

% Hilbert-Huang Transform decomposes signal into fundamental modes
x = sig;
sigtest = length(x)-100;
[d,v,inst_amp,~] = plot_hht(x,Ts); 
N = length(x);
c = linspace(0,(N-2)*Ts,N-1);
x = sig; amp = [];
dd = []; p1 = []; %df = [];
dd = cell2mat(d')'; dd = dd(:,1:6);
amp = cell2mat(emd(x)')'; amp = envelope(real(amp(:,1:6)),10,'rms');
amp(end,:) = [];
cmap = jet(250000);

% Dominant frequency has highest amplitude at each timestep
test = [];
for p = 1:size(dd,1)-1
    ind = find(abs(amp(p,:)) == max(abs(amp(p,:))));
    if round(dd(p,ind)) <= 0
        cc = NaN;
    else
        cc = round(dd(p,ind));
    end
    test(p,:) = [c(p), x(p), cc];
end
cc = test(:,3);

% Too high frequency data is removed to improve model training
[~, scalef, prefix2] = scaleSI(max(cc));
% cc(cc>(100/scalef)) = (100/scalef);
% cc(cc<(1/scalef)) = (1/scalef);

% Smoothes the data to improve model training
cc = nanfastsmooth(cc./(100/scalef),3,1);

%% Seismic Envelope
esig = double(envelope((x(1:sigtest))',10,'rms'));

amp = cell2mat(emd(x)')';
%esig = envelope((amp(:,3)+amp(:,4))',10,'rms');


%% Signal entropy
sn = nanfastsmooth(PE(x(1:sigtest),1,5,30),3,1);



