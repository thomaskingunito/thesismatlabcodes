%% Generates training vector
% Pre-signal noise is set to -1. Signal is set to 1. Post-signal noise is
% not set.

ptime = round(pk1(1));
etime = round(pk3(1));

if etime > sigtest
    t1 = [-ones(1,ptime-1),ones(1,length(p1)-ptime)];
else
    t1 = [-ones(1,ptime),ones(1,etime-ptime)];
end

inN = find(t1 == 1);
t2 = con2seq(t1(:,1:inN(end)));
p1 = [con2seq(cc(1:inN(end))');con2seq(esig(1:inN(end)));...
    con2seq(sn(1:inN(end)));];
