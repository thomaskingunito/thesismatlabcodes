%% Calculate various signal to noise ratios along the waveform

pk{r,1} = filename;
pk{r,2} = rayt(pk1);

a = pk1;
b = 2*a;
c = 3*a;
d = 4*a;
e = 1;

if d > length(signal(:,r))
    d = length(signal);
    adj = abs(d-c);
    b = a+adj;
    c = a+2*adj;
    e = a-adj;
end

cline1 = signal(a:b,r);
cline2 = signal(e:a,r);
pk{r,3} = rms(cline1)./... % signal 2 noise
    rms(cline2);

cline1 = signal(b:c,r);
cline2 = signal(e:a,r);
pk{r,4} = rms(cline1)./... % coda 2 noise
    rms(cline2);

cline1 = signal(c:d,r);
cline2 = signal(e:a,r);
pk{r,5} = rms(cline1)./... % reflection 2 noise
    rms(cline2);

cline1 = signal(a:b,r);
cline2 = signal(c:d,r);
pk{r,6} = rms(cline1)./... % signal 2 reflection
    rms(cline2);

cline1 = signal(b:c,r);
cline2 = signal(c:d,r);
pk{r,7} = rms(cline1)./... % coda 2 reflection
    rms(cline2);

cline1 = signal(a:b,r);
cline2 = signal(b:c,r);
pk{r,8} = rms(cline1)./... % signal 2 coda
    rms(cline2);

cline1 = signal(a:a+100,r);
try
    cline2 = signal(a-100:a,r);
catch
    cline2 = signal(1:a,r);
end
pk{r,9} = rms(cline1)./... % signal 2 coda
    rms(cline2);
