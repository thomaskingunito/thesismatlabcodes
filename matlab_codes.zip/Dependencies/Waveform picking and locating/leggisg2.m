

%[tracce,SR,Shot,X,n_samples] = leggisg2(nome_file);
%claudio ottobre 2003


function [tracce,SR,Shot,X,n_samples,RL] = leggisg2(nome_file)
fid=fopen(nome_file);

% legge il FILE DESCRIPTOR BLOCK:  4 short (8 byte), pi� 16 byte riservati
a=fread(fid,4,'short');  

(dec2hex(a(1)));		%indica che il file � seg2 se vale 3a55
(a(2)) 	;			   %numero della release
(a(3))	;				%dimensione in byte del trace pointer subblock
(a(4))	;				%numero di tracce nel file


num_tracce=a(4);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%legge il TRACE POINTER SUB-BLOCK, che inizia dal byte 32
fseek(fid, 32, -1); 									%si posiziona al 32o byte dall'inizio (-1 indica inizio file)
tr_descr_block=fread(fid,num_tracce,'int');	%legge tanti interi quanti indicati in num_tracce
%                                             (sono le posizioni dei blocchi delle varie tracce)
%dalla fine del TPS-B al primo TDB, ci sono delle stringhe varie che non guardiamo

%facendo un loop sul numero di tracce
for i=1:num_tracce
   fseek(fid,tr_descr_block(i),-1);		%mi posiziono all'inizio del Trace Descriptor Block
   
   ID_TDB=fread(fid,1,'short');	  		%Identificatore di TDB = 4422 in esadecimale
   size_TDB=fread(fid,1,'short');		%lunghezza in byte del TDB
   size_DB=fread(fid,1,'int');			%lunghezza del DATA BLOCK corrisponte, in byte
   n_samples=fread(fid,1,'int');			%numero di campioni nel DB
   data_format=fread(fid,1,'char');		%questo � il 12o byte: contiene il formato
   												%	1  -->  16 bit fixed point
	 												%	2  -->  32 bit fixed point
													%	3  -->  20 bit floating point   SEG-D
													%	4  -->  32 bit floating point		(IEEE standard)
													%	5  -->  64 bit floating point		(IEEE standard)
                                      
  % i byte dal 13 al 31 sono riservati
  %poi ci sono delle stringhe con informazioni varie: leggiamo tutto il blocco, poi cerchiamo di
  %estrarre le informazioni in esso contenute. Alcune delle informazioni sono uguali in tutte le 
  %tracce, come il Sampling Rate, il num di STACK ecc... , altre variano, come la posizione.
  
  fseek(fid,tr_descr_block(i)+32,-1);
  descstr=fread(fid,size_TDB-32,'char')';
  descstr=char(descstr);
  
  point_NC=findstr(descstr,'CHANNEL_NUMBER');
  point_NC=point_NC+length('CHANNEL_NUMBER');
      
  point_SR=findstr(descstr,'SAMPLE_INTERVAL');
  point_SR=point_SR+length('SAMPLE_INTERVAL ');
  
  point_LOC=findstr(descstr,'RECEIVER_LOCATION');
  point_LOC=point_LOC+length('RECEIVER_LOCATION');
  
  point_S=findstr(descstr,'SOURCE_LOCATION');
  point_S=point_S+length('SOURCE_LOCATION');
  
 %%%%%%%%%%
  RL(i,1)  = cellstr(descstr(point_LOC:(findstr(descstr,'RECEIVER_STATION_NUMBER')-4)));
 %%%%%%%%%% 
  SR=descstr(point_SR:point_SR+8);
  %quando il numero di cifre utilizzate varia a seconda del sampling rate utilizzato, meglio usare una funzione
  % di conversione tipo sscanf (string-->number) che butta via spazi e newlines
  SR=sscanf(SR,'%f');
  %SR=str2num(SR)
  
 if point_LOC
 Gx=descstr(point_LOC+1:point_LOC+3);
 Sx=descstr(point_S+1:point_S+3);
 X(i)=str2num(Gx); 
 Shot=[str2num(Sx)];
else
   Shot=0;
   X(i)=0;
end
  % ho letto le informazioni generali sulla misura e sul campionamento
  %		SR   = intervallo di campionamento
  %		STACK= numero di stack
  %		DATE = data dell'acquisizione
  %		TIME = ora dell'acquisizione
  %		X    = vettore con le posizioni X dei geofoni
  %		Y, Z = vettori con le altre posizioni dei geofoni
  %		Shot = coordinate della sorgente
  %		numchan= vettore col numero del canale corrispondente
  
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %%%%%   legge i dati veri e propri
     
  fseek(fid,tr_descr_block(i)+size_TDB,-1);
  
  if 		 data_format==1     	    tracce(:,i)=fread(fid,n_samples,'short');
  elseif  data_format==2           tracce(:,i)=fread(fid,n_samples,'int');
     
  elseif data_format==3  			
     %h=waitbar(0,'wait');
      for smp=1:n_samples/4
         exp1=fread(fid,1,'ubit4');
         exp2=fread(fid,1,'ubit4');
			exp3=fread(fid,1,'ubit4');
         exp4=fread(fid,1,'ubit4');
         tracce((smp-1)*4+1:(smp-1)*4+4,i)=fread(fid,4,'int16');
         tracce((smp-1)*4+1:(smp-1)*4+4,i)=tracce((smp-1)*4+1:(smp-1)*4+4,i).*(2.^[exp1; exp2; exp3; exp4]);
         
         end     
  %close(h)
  
  
  %tracce(:,i)=fread(fid,n_samples,'short');

%a=dec2bin(fread(fid,10,'ubit20'))

elseif data_format==4          
   
   tracce(:,i)=fread(fid,n_samples,'float');
   elseif data_format==5		    tracce(:,i)=fread(fid,n_samples,'double');
   end
end
fclose(fid);

if any(diff(X)<=0)
   X=(1:num_tracce)*0.001;
end
if ~Shot
   Shot=0;
end
