%% Calculate 'quality' ratios

% Windowing
a = pk1; b = 2*a; c = 3*a; d = 4*a; e = 1;
if d > length(x)
    d = length(x); adj = abs(d-c); b = a+adj; c = a+2*adj;  e = a-adj;
end
if b > length(x); b = length(x); end
if e < 1; e = 1;  end

% Long term signal 2 noise
cline1 = x(a:b);
cline2 = x(e:a);
sn1 = rms(cline1)./... 
    rms(cline2);

% Short term signal 2 noise
cline1 = x(a:a+round(sigsamp/40.96));
try
    cline2 = x(a-round(sigsamp/40.96):a);
catch
    cline2 = x(1:a);
end
sn2 = rms(cline1)./... 
    rms(cline2);

% Model output ratio
cline1 = yp(a:a+100);
cline2 = yp(1:a);
sn3 = rms(cline1)./... 
    rms(cline2);

