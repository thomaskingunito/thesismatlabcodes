%% Train Picking Model
% This is semi-supervised programme to train a distributed time delay
% neural network to recognise the differences between pre-signal noise and
% signal. It has two main elements;
%   1) A supervised picking stage where the user manually selects the time
%   of arrival on 5 high amplitude waveforms.
%   2) An unsupervised picking stage where the algorithm is sequentially
%   trained automatically using several 'quality' ratios to asses the data
% It is suggested to create a unique picking model for each experiment.
% Training datasets are created from the experimental data itself (stored
% in folder sg2). Model is trained in sequential batches and steadily 
% improves as more data is incorporated.

%% Version
% Version 1.0, 16th January 2019. Thomas King
%   - First Version

%% Parameter Customisation
% Below are the suggested parameters to be modified. I don't recommend
% changing any of the code outside of these parameters.

clear all; close all;

% This is the name of the picking model. I recommend to use folder names to
% avoid confusion as this testname is required when using the locating code
testname = 'Example-Training-Model';

% Set to 1 (yes) or 0 (no) to compile the training dataset
compile = 0;

% Resamples waveforms to a shorter length. It can increase the speed of the
% code but time resolution is lost.
sigsamp = 2048;

% Minimum arrival time. Recommended at 10% of signal length
minpick = round(sigsamp/10);

% Neural network parameters
d1 = 0:20; d2 = 0:5; % Delays
dtdnn_net = distdelaynet({d1,d2},5); % Hidden sizes set to 5
dtdnn_net.trainFcn = 'trainbr'; % Model trained with bayesian regularisation
dtdnn_net.divideFcn = '';
dtdnn_net.trainParam.epochs = 10; % Model is trained for 10 epochs per sequence
dtdnn_net.trainParam.min_grad = 3e-4;

% Manual training size
manualsize = 5;

% Size of training dataset
trainingsize = 10000;

% Number of training events per sequence
batchsize = 10;

% Final number of events to be in the model
modelsize = 304;

%% Data compilation
% To avoid continual re-reading of data, training waveforms are compiled
% into a single matrix

if compile == 1
    index = 0;
    dirls = dir('sg2/*seg2'); % Directory search for waveforms
    index = 0; clear event
    for i = 1:size(dirls,1)
        event{i,1} = dirls(i).name; % Compile filenames
    end
    cd sg2;
    for i = 1:length(event)
        t = randi(length(event)); % Random waveform selection
        try
            [signal,SR] = leggisg2(char(event{t})); % Load data
            if index == 0
                Ts = SR; % Obtain sampling rate
                Fs = 1/SR; % Obtain sampling frequency
            end
        catch
            continue
        end
        for r = 1:size(signal,2)
            index = index+1; % Compiles data into a single matrix
            allsig(:,index) = resample(signal(:,r),sigsamp,length(signal(:,r)));
        end
        if index > trainingsize % Stop compiling when dataset is big enough
            break
        end
        
    end
    cd ..
    save rays.mat allsig SR % Store waveform data
end
load rays.mat
Ts = SR*10;
Fs = 1/SR;

%% Supervised Training with high amplitude data
% Interactive manual picking for initial training dataset. User picks the
% onset and end of the main pulse of the waveform. If the onset is
% uncertain, click twice off of the graph to the right to skip that data.

% Reset parameters
p = []; t = [];
index = 0;
istore = 0;

while index < manualsize
    
    % Randomly find high amplitude waveform
    amp = 1;
    while amp > 0.1
        i = 0;
        while ismember(i,istore) == 1
            i = randi(size(allsig,2));
        end
        sig = allsig(:,i); sig = sig./max(abs(sig));
        amp = max(abs(sig(1:100)));
    end
    sig = allsig(:,i);
    
    % Compiles input data
    try
        IFcontent
    catch
        continue
    end
    
    % Interactive picking plot
    y = (test(:,2)./max(test(:,2)))';
    y(end) = NaN;
    col = cc'.*scalef;  % This is the color, vary with x in this case.
    figure(1); subplot(2,1,1); yyaxis left; cla;hold on
    patch(1:1:length(y),y,col,'EdgeColor','interp','Marker','none',...
        'MarkerFaceColor','flat','LineWidth',2);
    colormap(jet)
    xlim([0 sigsamp])
    figure(1); subplot(2,1,2); yyaxis left; cla;hold on
    plot(esig,'r-')
    yyaxis right; cla;
    plot(sn,'b-')
    xlim([0 sigsamp])
    title('Pick signal pulse start')
    [pk1,pk2] = ginput(1);
    title('Pick signal pulse end')
    [pk3,pk2] = ginput(1);
    
    sigtest = sigsamp;
    
    % Training sequence
    if pk1 < sigtest && minpick ~= pk1
        
        % Compiles training vectors
        try
            training_vector
        catch
            continue
        end
        
        % Train the model
        index = index + 1;
        if index > 1
            p_mul = catsamples(p_mul,p1,'pad');
            t_mul = catsamples(t_mul,t2,'pad');
            [p,Pi,Ai,t] = preparets(dtdnn_net,p_mul,t_mul);
            dtdnn_net = train(dtdnn_net,p,t,Pi);
            
            % Sometimes the training fails and the model breaks, this is a
            % workaround.
            if sum(isnan(tr.gradient)==1) > 0 | tr.gradient > 100
                load(char(['pkmodel-',char(testname),'.mat']),'p_mul','t_mul',...
                    'dtdnn_net','sigstore','istore')
                continue
            else
                istore = [istore;i]; % Do not repeat waveforms in model
                sigstore{end+1} = sig;
                save(char(['pkmodel-',char(testname),'.mat']),'p_mul','t_mul',...
                    'dtdnn_net','sigstore','istore')
            end
        else
            % Builds initial model for first waveform. Modify this add more
            % data categories
            dtdnn_net.numinputs = 3;
            dtdnn_net.inputConnect = [1 1 1; 0 0 0];
            dtdnn_net = configure(dtdnn_net,p1);
            
            dtdnn_net.inputWeights{1,1}.delays = [0:1:10];
            dtdnn_net.inputWeights{1,2}.delays = [0:1:10];
            dtdnn_net.inputWeights{1,3}.delays = [0:1:10];
            
            [dtdnn_net,tr] = train(dtdnn_net,p1,t2);
            p_mul = p1;
            t_mul = t2;
            sigstore{1} = sig;
        end
    end
end

save(char(['pkmodel-',char(testname),'.mat']),'p_mul','t_mul','dtdnn_net',...
    'sigstore','istore')

%% Unsupervised training
% This section works in the same way as before but uses 'quality' ratios
% to select training data

% Reset parameters
load rays.mat; close all;
load(char(['pkmodel-',char(testname),'.mat']),'p_mul','t_mul','dtdnn_net',...
    'sigstore','istore')
i = 0;
ampadj = 0;
pick_p1_cat = [];
pick_t2_cat = [];

% Training sequence
testindex = 0;
while size(p_mul{1,1},2) < modelsize
    Ts = 1/Fs;
    amp = 2;
    while amp >= 0.95 || amp < 0.05 % Amplitude range
        i = istore(1);
        while ismember(i,istore) == 1
            i = randi(size(allsig,2));
        end
        sig = allsig(:,i); sig = sig./max(abs(sig));
        amp = max(abs(sig(1:100)));
    end
    
    sig = allsig(:,i);
    Ts = Ts*(length(sig)/sigsamp);
    
    try
        IFcontent
    catch
        continue
    end
    
    y = (test(:,2)./max(test(:,2)))';
    y(end) = NaN;
    col = cc'.*scalef;  % This is the color, vary with x in this case.
    figure(1); yyaxis left; cla;hold on
    patch(1:1:length(y),y,col,'EdgeColor','interp','Marker','none',...
        'MarkerFaceColor','flat');
    colormap(jet)
    
    p1 = [con2seq(cc(1:length(sn))');con2seq(esig(1:length(sn)));...
        con2seq(sn(1:length(sn)));];
    
    % Using the current model iteration, the current waveform is picked
    o = 0; % Tells the picking code that this is a training sequence
    try
        pick_output_3
    catch
        continue
    end
    
    figure(1); yyaxis left;
    plot(yp,'k-')
    ylim([-2 2])
    drawnow
    pk1 = ind(1);
    
    % Finds the end of the main pulse, otherwise training vector is a fixed
    % length. Data is then plotted
    try
        esig2 = double(envelope((x(1:sigtest))',50,'rms')); 
        esig2 = esig2./max(abs(esig2));
        pk3 = find(esig2(round(pk1+(sigsamp/20.48)):end) < ...
            max(esig2(round(pk1-(sigsamp/20.48))-100:round(pk1-(sigsamp/20.48))))); 
        pk3 = pk3(1) + round(pk1+100);
    catch
        pk3 = pk1 + 200;
    end
    figure(1); yyaxis left;
    scatter(pk1,0,'bo','filled')
    try
        scatter(ind2,0,'ro','filled')
        plot(yp2,'r-')
    end
    scatter(pk3,0,'bo','filled')
    drawnow
    
    % Picking 'quality' ratios
    try
        output_quality
    catch
        continue
    end
    
    % Do NOT adjust these values. They work.
    if sn3 > 0.3 && sn2 > 2 && sn1 > 1.5 && minpick ~= pk1
        try
            training_vector
        catch
            continue
        end
        
        p_mul = catsamples(p_mul,p1,'pad');
        t_mul = catsamples(t_mul,t2,'pad');
        testindex = testindex +1;
        plot(yp,'r-')
        istore = [istore;i];
        sigstore{end+1} = sig;
        if testindex > batchsize
            testindex = 0;
            [p,Pi,Ai,t] = preparets(dtdnn_net,p_mul,t_mul);
            [dtdnn_net,tr] = train(dtdnn_net,p,t,Pi);
            
            if sum(isnan(tr.gradient)==1) > 0
                load(char(['pkmodel-',char(testname),'.mat']),'p_mul','t_mul',...
                    'dtdnn_net','sigstore','istore')
                continue
            else
                ampadj = ampadj + (0.5/150);
                save(char(['pkmodel-',char(testname),'.mat']),'p_mul','t_mul',...
                    'dtdnn_net','sigstore','istore')
                display(['Number of training data: ',num2str(size(p_mul{1,1},2))]);
            end
        end
    end
end
save(char(['pkmodel-',char(testname),'.mat']),'p_mul','t_mul','dtdnn_net',...
    'sigstore','istore')
display(['Number of training data: ',num2str(size(p_mul{1,1},2))]);

