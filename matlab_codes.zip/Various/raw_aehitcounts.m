%% Mechanism Probability Density Plots
% This code plots the focal mechanisms as probability densities against
% time or strain

%% Version
% Version 1.0, 27th January 2019. Thomas King
%   - First Version

%% Parameter customisation
% Below are the suggested parameters to be modified. I don't recommend
% changing any of the code outside of these parameters.

clear all;% close all


% Time Corrections
timecorr = 0;

% Compile data

% load mechanical data
stress_strain

% Compile Training Data

        dirls = dir('sg2/*seg2');
        index = 0; clear event bvaluetable straintime
        for i = 1:size(dirls,1)
            event{i,1} = dirls(i).name;
        end
      
        for i = 1:length(event)

                filename = event{i};
                filename([9,16,20:end]) = '-';
                formatIn = 'yyyymmdd-HHMMSS-fff---------';
                time = datenum(filename,formatIn) - start - timecorr;
                if time < 0 || time > max(deform(:,1))
                    continue
                end
                index = index + 1;
                 straintime(index) = mean(deform(abs(deform(:,1) - time) == ...
                     min(abs(deform(:,1) - time)),2));
            end



%
figure(14); 
subplot(2,2,2);cla;

                %set(gca,'ycolor',[[0 0 0]; [0 0 0]]);
                yyaxis left
               

                histogram(straintime,[0:0.025:max(deform(:,2))+0.1],'facecolor',[0 0 0],'edgecolor','none','facealpha',1)
                set(gca,'ycolor','k') 
                %ylim([0 50])
                ylabel('AE count')
                xlabel('Strain (%)')
                xlim([0 max(deform(:,2))])
                [a,b] = histc(straintime,[0:0.025:deform(stress(:,2)==max(stress(:,2)),2)]);
                
                ylim([0 1.1*max(max(a))])
                yyaxis right;cla;
                
                plot(deform(:,2),(stress(:,2)),'-','color',[0.5 0.5 0.5],'linewidth',5);hold on;
                plot(deform(:,2),(stress(:,2)),'k-','linewidth',3);
                set(gca,'ycolor','k') 
                ylim([0 1.1*max(max(stress(:,2)))])
                ylabel('D. Stress (MPa)')
                set(gcf,'color','w')
                xt = get(gca, 'YTick');
                set(gca, 'FontSize', 16,'Ycolor','k')
                xt = get(gca, 'XTick');
                set(gca, 'FontSize', 16)
               % set(gcf,'position',[680   646   601   332])
