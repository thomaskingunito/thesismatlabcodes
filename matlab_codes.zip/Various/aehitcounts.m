% Use with straintime to plot event counts histogram                

figure(14); 
                set(figure(14),'defaultAxesColorOrder',[[0 0 0]; [0 0 0]]);
                yyaxis left

                histogram(straintime,round(length(straintime)/10),'facecolor',[0 0 0],'edgecolor','none','facealpha',1)
                ylim([0 50])
                ylabel('AE count')
                xlabel('Strain (%)')
                xlim([0 max(deform(:,2))])
                yyaxis right;
                
                plot(deform(:,TorS),(stress(:,2)),'-','color',[0.5 0.5 0.5],'linewidth',4);
                plot(deform(:,TorS),(stress(:,2)),'k-','linewidth',3);
                ylabel('Differential Stress (MPa)')
                set(gcf,'color','w')
                xt = get(gca, 'YTick');
                set(gca, 'FontSize', 16,'Ycolor','k')
                xt = get(gca, 'XTick');
                set(gca, 'FontSize', 16)
                set(gcf,'position',[680   646   601   332])