%load mapstore.mat
close all
stress_strain

for k = 1:size(mapstore,1)
    vq = mapstore{k,4};
%     vq(vq>5e-4) = 5e-4;
%     vq(vq<-5e-4) = -5e-4;
    deviation(k) = diff([mean(vq(vq<-1e-4 & vq>-2e-4)) mean(vq(vq<2e-4 & vq>1e-4))]);
    strainave(k) = mapstore{k,1};
end

deviation(deviation<0) = (deviation(deviation<0) ./max(abs(deviation(deviation<0)))).*0.02;
deviation(deviation>0) = (deviation(deviation>0) ./max(abs(deviation(deviation>0)))).*0.02;
deviation = smooth(deviation,round(length(deviation)/10),'rloess');

figure; plot(strainave,deviation)

%%
for k = 1:size(mapstore,1)
    close all;
    open mechanim.fig
    subplot(1,2,2)
    ind = find(abs(mapstore{k,1} - deform(:,2)) == min(abs(mapstore{k,1} - deform(:,2))));
    scatter(mapstore{k,1},stress(ind(1),2),100,'ko','filled')
    scatter(mapstore{k,1},stress(ind(1),2),70,'ro','filled')
    subplot(1,2,1)
    cla; hold on;
    title([num2str(mapstore{k,1}),'% Strain'])
    pbaspect([4 10, 1])
    xlim([-0.02 0.02])
    ylim([-0.05 0.05])
    
    x = mapstore{k,2}; x = -x(:);
    y = mapstore{k,3}; y = y(:);
    vq = mapstore{k,4};
    %vq = vq - mean(vq);
    
    colormap(jet);
   
    %[a,b] = histcounts(vq,11);%(x < 0.015 & x > -0.015 & y < 0.025 & y > -0.025)
    
%     b = b(1:end-1) + (mean(diff(b))/2);
%     
%     ind = find(abs(b) == min(abs(b)));
%     vq = vq - b(ind(1));
%     [a,b] = histcounts(vq,11);
% %     
%     %if max(b) > 5e-3
%         vq(vq>5e-3) = 5e-3;
%         vq(vq<-5e-3) = -5e-3;
%         lim = 5e-3;
%     else
        vq(vq>5e-4) = 5e-4;
        vq(vq<-5e-4) = -5e-4;
        lim = 5e-4;
  %  end
    
       contourf(-mapstore{k,2},mapstore{k,3},reshape(vq,...
        size(mapstore{k,2},1),size(mapstore{k,2},2)),11,'LineStyle','none')
    
    cmin = -lim;
    cmax = lim;

    caxis([cmin cmax])

    colorbar('location','southoutside','Ticks',[cmin,cmax],...
        'TickLabels',{'Compaction','Dilation'},'FontSize',16)
    
    % Plot bounding box
    plot([-0.02 -0.02 0.02 0.02 -0.02],[-0.05 0.05 0.05 -0.05 -0.05],'k-')
    
    plot([deviation(k) 0],[-0.05 -0.05],'r-','linewidth',4)
    
    % 1cm Scale bar
    plot([-0.019 -0.019 -0.009 -0.009],[-0.0479 -0.049 -0.049 -0.0479],'k-','linewidth',3)
    plot([-0.019 -0.019 -0.009 -0.009],[-0.048 -0.049 -0.049 -0.048],'w-','linewidth',1.5)
    
    % Plot stuff
    set(gca,'xtick',[])
    set(gca,'xticklabel',[])
    set(gca,'ytick',[])
    set(gca,'yticklabel',[])
    set(gca,'box','off')
    set(gcf,'color','w')
    
    drawnow
    display(k)
    
    if anim == 1
        cd focalmechanimation
            set(gcf,'units','normalized','outerposition',[0 0 1 1])
            saveas(gcf,[num2str(k),'.png'])
        cd ..
    end
end