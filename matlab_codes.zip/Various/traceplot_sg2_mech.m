clear all; close all

load('recloc.mat');
load('sourceloc_ml.mat');
load('pktimes_ml.mat')
load eventdatamech_ml_residual.mat

stress_strain

ind = find(diff(deform(:,2)) > 0.02);
failuretime = deform(ind(1),1);

ind = [];
for i = 1:size(eventdata,1)
    
    if isempty(eventdata{i,14}) == 1
        continue
    end
    
    eventdata{i,2} = eventdata{i,2} - start;% - 641;
    
    ind = [ind,i];
end
eventdata = eventdata(ind,:);

ind = [];
for i = 1:size(sourcelocs,1);
    
    for j = 1:size(eventdata,1)
        
        test = strcmp(sourcelocs{i,1},eventdata{j,1});
        if test == 1
            ind = [ind,i];
            break
        end
        
    end
end
sourcelocs = sourcelocs(ind,:);
pktimes = pktimes(:,:,ind);
modlist = {'fitCLVD','fitDCB','fitDCQ','fitMM','fitISO'};

%sources = dlmread('animationevents.txt','%f');
%sources = dlmread('AElocs12.txt','%f');


Wn = ([1 481]) / 1000;
[z,p,k] = butter(6,Wn,'bandpass'); %butter filter
[sos,g] = zp2sos(z,p,k);      % Convert to SOS form
Hd = dfilt.df2tsos(sos,g);

eindex = 0;

sandstoneperiods = [0,0.006002939771861,0.007322476827540,0.008739027776755,max(deform(:,1))];

%%
%close all
eindex = 0;
hyp1 = -0.01;
for f = 1%:3

%ind = find(cell2mat(eventdata(:,2)) < failuretime);

ind = find(cell2mat(eventdata(:,2)) >= sandstoneperiods(1) &...
            cell2mat(eventdata(:,2)) <= sandstoneperiods(4));
        
%ind = 1:30;
zz = ind;
hyp = 0;
%hyp = 1;
hyp1 = hyp1+0.02;
cd sg2; 
% tic
% while hyp < hyp1
%     if toc > 4
%         display('fail')
%         cd ..
%         return
%     end
t = 0;
while t == 0
n = datasample(zz',1);

if mean(ismember(eventdata{n,14},'fitDCQ')) ~= 1
    continue
end
t= 1;
end

        [signal,SR] = leggisg2(char(sourcelocs(n,1))); %plot(filter(Hd,signal(:,i))+(i*max(max(signal(:,:)))));
        
    if exist('tfix') == 0
            X = signal(:,1);
            Ts = SR;
            Fs = 1/SR;           % Sampling frequency
          
            L = length(X);    % Length of signal
            rayt = (0:L-1)*Ts;          % Time vector
            rayt = rayt*10000;
        end


[~,order] = sort(rms(signal),'descend');


%end
cd ..
eventinfo = cell(2,8,12);
for col = 1:12

hyp = norm(cell2mat(sourcelocs(n,2:4)) - recloc(col,:));

ptime = cell2mat(pktimes(col,2,n));
eindex = eindex+1;

eventinfo{1,1,col} = 'Pick Time';
eventinfo{1,2,col} = 'Mechanism';
eventinfo{1,3,col} = 'Hypocentral dis';
eventinfo{1,4,col} = 'Period';
eventinfo{1,5,col} = 'Time';
eventinfo{1,6,col} = 'Amplitude';
eventinfo{1,7,col} = 'source_pos';
eventinfo{1,8,col} = 'receiver_pos';

eventinfo{2,1,col} = ptime;
eventinfo{2,2,col} = eventdata{n,14};
eventinfo{2,3,col} = hyp;
eventinfo{2,4,col} = '1';
eventinfo{2,5,col} = rayt;
eventinfo{2,6,col} = signal(:,col) - mean(signal(:,col));
eventinfo{2,7,col} = cell2mat(sourcelocs(n,2:4));
eventinfo{2,8,col} = recloc(col,:);

end
end
%return

freq = [50,900;50,100;100,200;200,400;400,800];

for col = 1:12

figure(1); 
for i = 1:5
subplot(12,5,i+((col-1)*5)); cla
pbaspect([1,1,1])
hold on

x = rayt;

% Wn = ([freq(i,1) freq(i,2)]) / 1000;
% [z,p,k] = butter(6,Wn,'bandpass'); %butter filter
% [sos,g] = zp2sos(z,p,k);      % Convert to SOS form
% Hd = dfilt.df2tsos(sos,g);
csig = signal(:,col);% - mean(signal(:,col));
if i > 1
    [csig,Hd] = bandpass(csig,[freq(i,1)*1000 freq(i,2)*1000],Fs);
end

%csig = filter(Hd,csig);

p1 = plot(x,csig,'k-','linewidth',0.5);
esig = smooth(envelope(csig,freq(i,2)/10,'rms'),100);

a = round(ptime/Ts); b = length(csig)-100;

maxE = find(esig(a:b) == max(esig(a:b)))+a;

p3 = plot([x(round(ptime/Ts)) x(maxE)],[esig(maxE)*0.75,esig(maxE)*0.75],'r-','linewidth',3);
text(x(round(ptime/Ts)-75),esig(maxE)*0.75,'\bf t_p','color','r','fontsize',12)
%text(x(20),max(abs(csig)),'\it Pre-Failure','color','k','fontsize',12)

set(gcf,'color','white')

p1.Color(4) = 1;

grid on
ylim([-1.1*max(abs(csig)) ...
    1.1*max(abs(csig))])
xlim([0 max(rayt)/2])
xt = get(gca, 'YTick');
    set(gca, 'FontSize', 16,'Ycolor','k')
    xt = get(gca, 'XTick');
    set(gca, 'FontSize', 16)
    ylabel('Amplitude (volts)')
    xlabel('Time (ms)')
    %title([num2str(hyp),' ',eventdata{n,14}])
end
end
return
    %%
cd('sandstone figures and data')
    save(['eventinfo_',eventinfo{2,2,1},'_',eventinfo{2,4},'_hyp_',num2str(round(hyp,4)),'.mat'],'eventinfo')
cd .. 

    return
%%
figure(1); cla;
hold on
plot(signal(round(ptime/T)-100:round(ptime/T)+900,col),'k-','linewidth',1.5)
set(gca,'Visible','off')
set(gcf,'color','white')
pbaspect([3 1 1])
axis off
grid off
set(gcf,'position',[852   467   541   273])

%%
figure(2); cla;
hold on
width = 3;
[~,order] = sort(rms(signal),'descend');
ptime = cell2mat(pktimes(order(1),2,n));
sig = signal(round(ptime/T)-100:end,order(1));
sig(1000:end) = 0;
sig = smooth(envelope(sig,100,'rms'),150,'loess');

x2 = x(1:1001);
for i = 1:7
    if i == 1
plot(x2(1:1001),sig(1:1001),'k-','linewidth',width)
    else
        plot(x2(1:1001),sig(1:1001),'k--','linewidth',width)
    end
set(gca,'Visible','off')
set(gcf,'color','white')
pbaspect([3 1 1])
axis off
grid off
width = width - (2.5/7);
xlim([x(1) x(1000)])

x2 = x(1:1001).*(1+(i/5));
x2 = x2-min(x2);
sig = sig.*(1-(i/20));
end
%%
set(gcf,'position',[852   467   541   273])
%ylim([-9.3414e-04   9.3414e-04])
%%
figure
hold on
Wn = ([90 110]) / 1000;
[z,p,k] = butter(6,Wn,'bandpass'); %butter filter
[sos,g] = zp2sos(z,p,k);      % Convert to SOS form
Hd = dfilt.df2tsos(sos,g);
p1 = plot(filter(Hd,signal(:,col) - mean(signal(:,col))),'k','linewidth',1)
plot(smooth(abs(filter(Hd,signal(:,col) - mean(signal(:,col)))),800,'loess'),'r','linewidth',2)
% Wn = ([350 400]) / 1000;
% [z,p,k] = butter(6,Wn,'bandpass'); %butter filter
% [sos,g] = zp2sos(z,p,k);      % Convert to SOS form
% Hd = dfilt.df2tsos(sos,g);
% p2 = plot(filter(Hd,signal(:,col) - mean(signal(:,col))),'r')
% Wn = ([1 20]) / 1000;
% [z,p,k] = butter(6,Wn,'bandpass'); %butter filter
% [sos,g] = zp2sos(z,p,k);      % Convert to SOS form
% Hd = dfilt.df2tsos(sos,g);
% p3 = plot(filter(Hd,signal(:,col) - mean(signal(:,col))),'b')
% xlim([0 2048])
% p1.Color(4) = 0.5;
% p2.Color(4) = 1;
% p3.Color(4) = 1;
set(gca,'Visible','off')
set(gcf,'color','white')
%ylim([-12e-01 12e-01])

find(zz ==n)

%% Match animation points

% load win.mat
% clear winevents midevent
% midevent = cell(size(win,1),1);
% for i = 1:size(win,1)
%     
%     ind = find(sources(:,4) > win(i,6)-(0.3*(win(3,6) - win(2,6))) & sources(:,4) < win(i,6)+(0.3*(win(3,6) - win(2,6))));
%     if isempty(ind) == 0
%         midevent{i} = sources(ind,:);
%     end
%     winevents = sources(ind,:);
%     
%     save animationevents.txt winevents -ascii
%     movefile('animationevents.txt',['animationevents/animationevents_frame',num2str(i),'.txt'])
% end
% 
% %save animationevents.txt midevent -ascii
    