%% Peak Delay Plotting
% Plots peak delay in various forms

%% Version
% Version 1.0, 12th February 2019. Thomas King
%   - First Version

%% Parameter customisation
% Below are the suggested parameters to be modified. I don't recommend
% changing any of the code outside of these parameters.

clear all; close all; warning off all

% Spatial maps parameters
modstp = 0.005; % Grid size used in mapping
numwin = 1; % Splits data into a number of time windows
numrays = 1000; % Maximum number of rays to use in maps, smaller = faster
deg = -70; % Rotate data for 2D maps
minrays = 2; % Mininum number of raypaths per grid block
smoothing = 1.1; % Smoothing parameter

% Corrections
timecorr = 0;%132+182;

%% Compile

% Load data

load peakdelay_measurements.mat
load peakdelayrays.mat
load recloc.mat

% Time calibration
stress_strain
rayparam(:,4) = rayparam(:,4) - start - timecorr;

nevents = round(size(rayparam,1)/numwin); % Fixed number of events

% Data sorting
[~,order] = sort(rayparam(:,4));
rayparam = rayparam(order,:);
lapse = lapse(order,:);
lapseerr = lapseerr(order,:);

% Data cleaning
tlim = [-8.91 -9.415 -9 -9.15]; % e.g. Mie resonance thresholds
for fr = 1:size(lapse,2)
   % ind = find(log(lapse(:,fr)) > tlim(fr)); % For example, anomalously high delays
      ind = find(lapseerr(:,fr) > 50 | lapseerr(:,fr) < 2 | ...
          log(lapse(:,fr)) > tlim(fr)); % Or too low Peak SNR
  %   ind = find(lapseerr(:,fr) > 2 & log(lapse(:,fr)) > tlim(fr) & lapseerr(:,fr)<200);
     lapse(ind,fr) = NaN;
    ind = 1:1:length(lapse(:,fr));
    
    if fr == 1
        indmem = ind;
    else
        ind2 = find(ismember(indmem,ind));
        indmem = indmem(ind2);
    end
end
ind = indmem;
rayparam = rayparam(ind,:);
lapse = lapse(ind,:);
lapseerr = lapseerr(ind,:);

% Compile into single cell array
for fr = 1:size(lapse,2)
    clapse = lapse(:,fr);
    cerr = lapseerr(:,fr);
    crayparam = rayparam;
    lapsetimes{fr,1} = clapse;
    lapsetimes{fr,2} = crayparam;
    lapsetimes{fr,4} = cerr;
end

%% Peak delay vs. time

% Time of sample failure
ind = find(diff(deform(:,2)) > 0.02);
failuretime = deform(ind(1),1);
factors = FindClosestFactorization(size(lapse,2));

for fr = 1:size(lapse,2)
    
    % Load
    cerr = lapsetimes{fr,4};
    crayparam = lapsetimes{fr,2};
    clapse = lapsetimes{fr,1};
    
    % Normalise around average
    clapse = clapse - mean(clapse(isnan(clapse)==0));
    
    % Calculate standard error in bins
    err = []; smtlapse = []; smoot = 1500;
    for e = 1:length(clapse)
        try
            chk = clapse(e-round(smoot/2):e+round(smoot/2));
            chk = chk(isnan(chk)==0);
            smtlapse(e) = mean(chk);
            err(e) = std(chk)/sqrt(length(chk));
        catch
            err(e) = NaN;
            smtlapse(e) = NaN;
        end
    end
    
    % Plotting
    figure(1); subplot(factors(1),factors(2),fr);
    title([num2str(freq(fr,3)),'KHz'])
    yyaxis left; cla
    shadedErrorBar(crayparam(:,4),smtlapse,err,'lineprops','k')
    ylabel('Peak Delay')
    xt = get(gca, 'YTick');
    set(gca, 'FontSize', 16,'Ycolor','k')
    xt = get(gca, 'XTick');
    set(gca, 'FontSize', 16)
    set(gcf,'color','white')
    yyaxis right; cla;
    hold on
    plot(smooth(deform(:,1),100),(stress(:,2)),'w-','linewidth',4);
    f = plot(smooth(deform(:,1),100),(stress(:,2)),'k-','linewidth',2);
    ylabel('D. stress (MPa)','Fontsize',24,'Color','k')
    xlabel('Experimental time (minutes)','Fontsize',24)
    
    xt = get(gca, 'YTick');
    set(gca, 'FontSize', 16,'Ycolor','k')
    xt = get(gca, 'XTick');
    set(gca, 'FontSize', 16)
    set(gcf,'color','white')
    xlim([deform(1,1) deform(end,1)])
    xticks([0:mean(diff(deform(:,1)))*round((max(deform(:,1))/mean(diff(deform(:,1))))/5):max(deform(:,1))])
    datetick('x','MM:SS','keeplimits')
    drawnow
end
%% Amplitude ratio counts
for fr = 1:size(lapse,2)
    
    % Load
    cerr = lapsetimes{fr,4};
    crayparam = lapsetimes{fr,2};
    
    % Sets a threshold value
    bmax = 25; % If plots come out blank, increase this value
    [c,d] = find(cerr>bmax);
    for j = 1:length(c)
        cerr(c(j),d(j)) = bmax;
    end
    
    % Before failure
    figure(2); subplot(factors(1),factors(2),fr); cla
    [a,b] = histcounts(cerr(crayparam(:,4) < failuretime),'BinEdges',[0:bmax/10:bmax]);
    [a2,b2] = histcounts(cerr(crayparam(:,4) > failuretime),'BinEdges',[0:bmax/10:bmax]);
    ind = find(a == max(a));
    a = a(ind:end); b = b(ind+1:end)-0.25;
    ind = find(a2 == max(a2));
    a2 = a2(ind:end); b2 = b2(ind+1:end)-0.25;
    histogram(cerr(crayparam(:,4) < failuretime),'BinEdges',[0:bmax/10:bmax],...
        'FaceColor',[0.65 0.65 0.65],'FaceAlpha',0.5)
    hold on;
    title([num2str(freq(fr,3)),' KHz before'],'Fontsize',16)
    try
        ylim([0 1.1*max(a(b<bmax))])
    end
    ylabel('Counts','Fontsize',16); xlabel('Peak amplitude to noise ratio','Fontsize',16)
    set(gcf,'color','w')
    xt = get(gca, 'YTick');
    set(gca, 'FontSize', 16,'Ycolor','k')
    xt = get(gca, 'XTick');
    set(gca, 'FontSize', 16)
    
    % After failure
    figure(3); subplot(factors(1),factors(2),fr); cla
    histogram(cerr(crayparam(:,4) > failuretime),'BinEdges',[0:bmax/10:bmax],...
        'FaceColor',[0 0 0],'FaceAlpha',0.5)
    hold on
    try
        ylim([0 1.1*max(a2(b2<bmax))])
    end
    ylabel('Counts','Fontsize',16); xlabel('Peak amplitude to noise ratio','Fontsize',16)
    title([num2str(freq(fr,3)),' KHz after'],'Fontsize',16)
    set(gcf,'color','w')
    xt = get(gca, 'YTick');
    set(gca, 'FontSize', 16,'Ycolor','k')
    xt = get(gca, 'XTick');
    set(gca, 'FontSize', 16)
    drawnow
    
end

%% Peak delay vs. frequency
mpeak = []; stack = [];
for fr = 1:size(lapse,2)
    
    % Load
    crayparam = lapsetimes{fr,2};
    clapse = lapsetimes{fr,1};
    
    % Stack data and take average
    mpeak(fr,:) = [freq(fr,3),mean(clapse(isnan(clapse)==0))];
    stack = vertcat(stack, [repmat(freq(fr,3),length(clapse),1),clapse, crayparam(:,4)]);
    
end

% Data fitting
p1 = polyfit(stack(stack(:,3)<failuretime,1),(stack(stack(:,3)<failuretime,2)),1);
p2 = polyfit(stack(stack(:,3)>failuretime,1),(stack(stack(:,3)>failuretime,2)),1);

% Plotting
figure(4); cla; title('Frequency')
scatter(stack(:,1),(stack(:,2)),5,[0.5 0.5 0.5],'filled'); hold on
plot(freq(:,3),freq(:,3)*p1(1)+p1(2),'r-'); % before
plot(freq(:,3),freq(:,3)*p2(1)+p2(2),'b-'); % after
ylabel('Peak Delay','Fontsize',16)
xlabel('Frequency (Hz)','Fontsize',16)
set(gcf,'color','w')
xt = get(gca, 'YTick');
set(gca, 'FontSize', 16,'Ycolor','k')
xt = get(gca, 'XTick');
set(gca, 'FontSize', 16)
drawnow

%% Peak Delay vs. hypocentral distance
b2 = [];
for fr = 1:size(lapse,2)
    
    % Load
    crayparam = lapsetimes{fr,2};
    clapse = lapsetimes{fr,1};
    
    % Data fitting
    y = (clapse);
    x = (crayparam(:,3));
    [~,order] = sort(x);
    x = x(order);
    y = y(order);
    ind = find(isnan(y) == 0 & isinf(y) == 0 & ...
        crayparam(:,3) > 0.02 & crayparam(:,3) < 0.04);% > 0 & err < 100);
    W = ones(length(x),1);
    W(log(y(ind)) > -11 & log(y(ind)) < -9) = 10;
    
    b2(:,fr) = flipud(wpolyfit(log(x(ind)),log(y(ind)),1,W(ind))');
    
    % Plotting
    figure(5); subplot(factors(1),factors(2),fr); cla; hold on
    scatter((x).*1000,log(y),5,[0.5 0.5 0.5],'filled')
    plot([min(x):0.001:max(x)].*1000,log([min(x):0.001:max(x)])*b2(2,fr) + b2(1,fr),'k-','Linewidth',2)
    title([num2str(freq(fr,3)),'KHz'],'Fontsize',16)
    ylabel('log(t_p) (ms)','Fontsize',16)
    xlabel('R (mm)','Fontsize',16)
    set(gcf,'color','w')
    xt = get(gca, 'YTick');
    set(gca, 'FontSize', 16,'Ycolor','k')
    xt = get(gca, 'XTick');
    set(gca, 'FontSize', 16)
    
    % Hypocentral distance correction
    cpobs = real(log(y) - log(x)*b2(2,fr) + b2(1,fr));
    tt = log(y);
    cpobs =real(log(y) - mean(isnan(tt)==0));
    cpobs(isinf(cpobs)==1) = NaN;
    dtpobs{fr,1} = cpobs;
    ylim([-13 -8.8])
    drawnow
    
end

%% Spatial mapping

[x,y,z] = meshgrid(-0.04:modstp:0.04,-0.04:modstp:0.04,-0.1:modstp/(5/2):0.1);
model = x(:);
model(:,2) = y(:);
model(:,3) = z(:);
model(:,4) = [1:1:size(model,1)];
modelbck = model; % backup

for n = 1:numwin
    for fr = 1:size(freq,1)
        
        % Load
        crayparam = lapsetimes{fr,2};
        
        % Ray tracing
        if fr == 1
            raypath = [];
            if n ~= numwin
                sources = [crayparam(nevents*(n-1)+1:nevents*n,5:7) crayparam(nevents*(n-1)+1:nevents*n,...
                    8:10) [1:1:length(crayparam(nevents*(n-1)+1:nevents*n,5))]' crayparam(nevents*(n-1)+1:nevents*n,4)];
            else
                sources = [crayparam(nevents*(n-1)+1:end,5:7) crayparam(nevents*(n-1)+1:end,...
                    8:10) [1:1:length(crayparam(nevents*(n-1)+1:end,5))]' crayparam(nevents*(n-1)+1:end,4)];
            end
            % Draw rays
            figure(6); cla; hold on
            for i = 1:round(size(sources,1)/numrays)+1:size(sources,1)
                
                % Source position
                x3 = sources(i,1);
                y3 = sources(i,2);
                z3 = sources(i,3);
                
                % Receiver position
                x4 = sources(i,4);
                y4 = sources(i,5);
                z4 = sources(i,6);
                
                % Event time
                t = sources(i,end);
                
                % Compiles rays
                raystep = 0:modstp/4:norm([x3 y3 z3] - [x4 y4 z4]);
                try; raypath2 = linspaceNDim([x3 y3 z3],[x4 y4 z4], length(raystep));
                catch; continue; end
                raypath2 = raypath2';
                raypath2(:,4) = sources(i,7);
                raypath2(:,6) = i;
                raypath2(:,10) = t;
                [~,ang] = rangeangle([x3 y3 z3]',[x4 y4 z4]');
                raypath2(:,7) = ang(1);
                % Plot rays
                plot3(raypath2(:,1),raypath2(:,2),raypath2(:,3),'color',[0.5 0.5 0.5])
                raypath = vertcat(raypath,raypath2);
                
            end
            
            % Plot source locations
            scatter3(sources(:,1),sources(:,2),sources(:,3),'ko','filled')
            
            % Rotate data
            XYZold = raypath(:,1:3); XYZold = XYZold'; x0=[0 0 0].'; u=[0 0 1].';
            [XYZnew, R, t] = AxelRot(XYZold, deg, u, x0); raypath(:,1:3) = XYZnew';
            
            XYZold = sources(:,1:3); XYZold = XYZold'; x0=[0 0 0].'; u=[0 0 1].';
            [XYZnew, R, t] = AxelRot(XYZold, deg, u, x0); sources2 = XYZnew';
            
            % Ray tracing
            for i = 1:size(raypath,1)
                [ind, d] =  dsearchn(model(:,1:3),raypath(i,1:3));
                ind = ind(d<modstp);
                try; raypath(i,5) = model(ind,4);
                catch; raypath(i,5) = model(ind(1),4);end
            end
            [C, IA, IC] = unique(raypath(:,4:6),'rows','stable');
            raypath = raypath(IA,:);
            raypathbck = raypath;
        end
        
        %% Reset
        raypath = raypathbck;
        model = modelbck;
        
        % Set data to current frequency band
        dtlapse =  dtpobs{fr,1};
        raypath(:,4) = dtlapse(raypath(:,4));
        load fit_datastore.mat p1 p2
%         
%         if fr == 1
%             raypath(:,4) = (raypath(:,4)-p1(1))/p1(2);
%         else
%             raypath(:,4) = (raypath(:,4)-p2(1))/p2(2);
%         end
%         raypath(:,4) = rayp
%         V = tp-p1/p2
%         tp = p1 + V*p2
          
%         
        % Find average value for each grid step
        for i = 1:size(model,1)
            ind = find(raypath(:,5) == i);
            ind2 = find(isnan(raypath(ind,4)) == 0);% & raypath(ind,4) > 0.008);
            ind = ind(ind2);
            if length(ind) > minrays
                val = raypath(ind,4);
               %val = val(isoutlier(val,'quartiles')==0);
                try
                    model(i,5)= mean(val);
                catch
                    model(i,5) = NaN;
                end
                % model(i,7) = std(val)/sqrt(length(ind)); % standard deviation of block
                model(i,7) = range(val); % or the range
                % model(i,5) = model(i,7); % Debugging
                model(i,8) = length(ind); % number of measurements
            else
                model(i,5) = NaN;
                model(i,7) = NaN;
                model(i,8)= NaN;
            end
        end
        
        % Plot smoothing
        for i = 1:size(model,1)
            if isnan(model(i,5)) == 1
                model(i,6) = NaN;
                continue
            end
            [Idx,D] = knnsearch(model(i,2:3),model(:,2:3));
            ind = find(D < modstp*smoothing);
            val = model(ind,5);
            val = val(find(isnan(val) == 0));
            model(i,6) = mean(val);
        end
        
        % Normalise to average
        ind = find(isnan(model(:,6)) == 1);
        mtp = mean(model(isnan(model(:,6)) == 0,6));
        model(ind,:) = [];
        model(:,6) = model(:,6) - mtp;
        
        % Regrid data onto a finer mesh
        [x,y] = meshgrid(-0.02:0.0001:0.02,-0.05:0.0001:0.05);
        vq = griddata(model(:,2),model(:,3),model(:,6),x(:),y(:));
        
        % Plotting
        figure(6+n);
        subplot(1,size(freq,1),fr); cla;
        contourf(x,y,reshape(vq,size(x,1),size(x,2)),11,'LineStyle','none')
        newmap = brighten(jet(11),-.2); colormap(newmap);
        hold on
        scatter(sources2(:,2),sources2(:,3),'k.')
        title(['[',num2str(freq(fr,1)/1000),'-',num2str(freq(fr,2)/1000),' KHz]'],'FontSize',16,'Color','k')
        set(gcf,'color','white')
        set(gca,'Visible','on')
        ylim([-0.05 0.05])
        xlim([-0.02 0.02])
        pbaspect([4 10 1])
        xt = get(gca, 'YTick');
        set(gca, 'FontSize', 16,'Ycolor','k')
        xt = get(gca, 'XTick');
        set(gca, 'FontSize', 16)
        h = colorbar('southoutside','FontSize',16,'Color','k');
        caxis([-0.1 0.1]) % colour limits
        xlabel(h,'\Deltalog(t_p)','FontSize',16,'Color','k')
        plot([-0.02 -0.02 0.02 0.02 -0.02],[-0.05 0.05 0.05 -0.05 -0.05],'k-')
        set(gca,'xtick',[])
        set(gca,'xticklabel',[])
        set(gca,'ytick',[])
        set(gca,'yticklabel',[])
        set(gca,'box','off')
        
        % Scale
        plot([-0.019 -0.019 -0.009 -0.009],[-0.048 -0.049 -0.049 -0.048],'k-','linewidth',1.5)
        text(-0.014,-0.0485,'1cm','HorizontalAlignment','center','VerticalAlignment','bottom','Fontsize',16)
        
        drawnow
    end
end
