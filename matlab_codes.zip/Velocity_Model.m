%% Generate Velocity Model
% Creates an output velocity model, identical to the one produced by
% InSite. Survey data (stored in sg2_survey) is automatically picked using
% an RMS amplitude threshold method. The code attempts to automatically
% avoid including miss-picked velcoties but it is here and there in terms
% of confidence.

%% Version
% Version 1.0, 16th January 2019. Thomas King
%   - First Version

%% Parameter Customisation
clear all; close all;

testname = 'Example-Training-Model';
sigsamp = 2048;
figon = 1;

%% Compile data

% Waveform origin time
tempi = [];
dirls = dir('sg2_survey/*seg2');
index = 0; clear event
event = cell(size(dirls,1),1);
for i = 1:size(dirls,1)
    event{i,1} = dirls(i).name;
    filename = event{i};
    filename([9,16,20:end]) = '-';
    formatIn = 'yyyymmdd-HHMMSS-fff---------';
    tempi(i,1) = datenum(filename,formatIn);
end
save tempi_survey.mat tempi

% Find receiver positions
if exist('recloc_survey') == 0 || exist('recloc') == 0
    cd sg2_survey
    filename = event{1};
    [tracce,SR,Shot,X,n_samples,RL] = leggisg2(char(filename));
    Ts = SR;
    Fs = 1/SR;
    for j = 1:size(RL,1)
        rec = strsplit(char(RL(j,:)));
        recloc(j,1) = str2num(rec{3}); % NED to XYZ
        recloc(j,2) = str2num(rec{2});
        recloc(j,3) = str2num(rec{4});
    end
    cd ..
    save recloc_survey.mat recloc
end

% Identify individual survey sequences
minpick = 525;
sepsurvey = diff(tempi);
ind = find(sepsurvey > 1e-4)+1;
ind = [1;ind;length(sepsurvey)+2];

% Source position equals receiver positions
index = 0;
for i = 2:length(ind)
    crows = [ind(i-1):1:ind(i)-1];
    if length(crows)~=size(recloc,1)
        continue
    end
    for r = 1:length(crows)
        index = index+1;
        sourcelocs{index,1} = event{crows(r)};
        sourcelocs{index,2} = recloc(r,1);
        sourcelocs{index,3} = recloc(r,2);
        sourcelocs{index,4} = recloc(r,3);
        sourcelocs{index,5} = tempi(crows(r));
    end
end

save sourceloc_survey_ml.mat sourcelocs

% Reset workspace
event = sourcelocs(:,1);
pktimes = cell(size(recloc,1),9,length(event));
i = 1;

%% Waveform Picking
i = i - 1;
ordersize= 0;
while i ~=size(event,1)
    % Reset
    pk = cell(size(recloc,1),9); sigM = ones(size(recloc,1),1);
    pk(:,:) = num2cell(NaN);
    sourcestore = cell(1,5);
    filename = [];
    
    % Load file
    i = i + 1;
    display(['Event ',num2str(i)])
    filename = event{i};
    cd sg2_survey 
    try
        [tracce,SR,Shot,X,n_samples,RL] = leggisg2(filename);
    catch
        cd ..
        pktimes(:,:,i) = pk;
        continue
    end
    signal = tracce; 
    cd ..
    
    % Picking
    if ordersize ~= size(recloc,1)
        ordersize = ordersize+1;
    else
        ordersize = 1;
    end
    for o = 1:size(signal,2)
        Ts = 1/Fs;
        r = o;
        % Does not pick source waveform
        if o == 1
            pk{r,1} = filename;
            pk{r,2} = NaN;
            pk(r,3:9) = num2cell(NaN);
            continue
        end
        % Does not pick receivers on same axis as source
        if ismember(recloc(r,1),recloc(ordersize(1),1)) && ismember(recloc(r,2),recloc(ordersize(1),2))
            pk{r,1} = filename;
            pk{r,2} = NaN;
            pk(r,3:9) = num2cell(NaN);
            continue
        end
        display(num2str(o))
        
        % Pads data
        n = randn(500,1); n = n./max(abs(n));
        n1 = n.*0.05;
        n = randn(sigsamp,1); n = n./max(abs(n));
        n2 = n.*0.05;
        sig = [n1;resample(signal(:,r)+n2,sigsamp,length(signal(:,r)))];
        Ts = Ts*(length(signal(:,r))/sigsamp);
        
        % Calculate signal envelope
        esig = envelope(sig,10,'rms');
        
        % Normalise envelope to pre-signal noise
        esig = esig./max(esig(1:200));
        
        % Finds first amplitude rise above noise
        ind = find(esig>1.1); ind = ind(ind > 550);
        try
            ind = ind(1);
        catch
            pk{r,1} = filename;
            pk{r,2} = NaN;
            pk(r,3:9) = num2cell(NaN);
            continue
        end
        
        % Calculate signal to noise ratio around first rise
        sn = []; testrange = 300;
        for s = 1:testrange
            try
                sn(s) = mean(esig((s+ind-round(testrange/2)):(s+ind-round(testrange/2))+100))/mean(esig((s+ind-round(testrange/2))-100:(s+ind-round(testrange/2))));
            catch
                sn(s) = NaN;
            end
        end
        
        % Picks highest signal to noise ratio
        try
            s = find(sn >= 2); % Preferably above 2
            s = s(1);
            ind = ind-round(testrange/2)+s;
        catch
             s = find(sn >= max(sn)); % Otherwise just the maximum
             s = s(1);
            ind = ind-round(testrange/2)+s;
        end
        
        % Correct for padding
        try
            pk1 = ind(1) - 500;
        catch
            pk{r,1} = filename;
            pk{r,2} = NaN;
            pk(r,3:9) = num2cell(NaN);
            continue
        end
        
        % Generate picking matrix with signal to noise ratios
        if ind(1) > minpick
            try
                rayt = [Ts:Ts:(length(signal)*Ts)];
                fill_pk
            catch
                pk{r,1} = filename;
                pk{r,2} = NaN;
                pk(r,3:9) = num2cell(NaN);
                continue
            end
        else
            pk{r,1} = filename;
            pk{r,2} = NaN;
            pk(r,3:9) = num2cell(NaN);
            continue
        end
        test = find(abs(sig) == max(abs(sig)));
        sigM(r)= test(1)*Ts;
    end
    
    % Removes late picking
    for q = 1:size(recloc,1)
        [~,order] = sort(cell2mat(pk(:,2)),'ascend');
        ind = find(diff(cell2mat(pk(order,2))) > 0.16e-4)+1;
        for p = 1:length(ind)
            r = order(ind(p));
            pk{r,2} = NaN;
            pk(r,3:9) = num2cell(NaN);
        end
    end
    
    % Plots waveforms and picks
    pktimes(:,:,i) = pk;
    if ismember(i,1:1:length(event)) == 1 && figon == 1
        [~,order] = sort(cell2mat(pk(:,2)),'ascend');
        stp = max(max(abs(signal)));
        figure(2); yyaxis left; cla
        for jj = 1:length(order)
            Ts = 1/Fs;
            try
                csig = signal(:,order(jj));
                plot(csig+(stp*(jj-1)),'k-'); hold on;
                scatter(round(pk{order(jj),2}/Ts),(stp*(jj-1)),'ro','filled')
            end
        end
        drawnow
    end
end

%% Write velocity model
% This writes the velocity model in the same structure as InSite

% Compile data
sepsurvey = diff(tempi);
ind = find(sepsurvey > 1e-4)+1;
ind = [1;ind;length(sepsurvey)+2];
vel = [];
rindex = 0;
for i = 2:length(ind)
    crows = [ind(i-1):1:ind(i)-1];
    if length(crows)~=size(recloc,1)
        continue
    end
    rindex = rindex+1; cindex = 0;
    for r = 1:length(crows)
        
        for r2 = 1:length(crows)
            cindex = cindex + 1;
            if r == r2
                vel(rindex,cindex) = NaN;
            else
                try
                    if pktimes{r2,3,crows(r)} < 2
                        vel(rindex,cindex) = NaN;
                        continue
                    end
                    dist = norm(recloc(r,:) - recloc(r2,:));
                    vel(rindex,cindex) = dist/pktimes{r2,2,crows(r)};
                    qual(rindex,cindex) = pktimes{r2,3,crows(r)};
                catch
                    vel(rindex,cindex) = NaN;
                end
            end
        end
    end
end

% Removes questionable picks
velim = [mean(vel(isnan(vel)==0))-2000 mean(vel(isnan(vel)==0))+2000];
for p = 1:size(vel,1)
    [~,order] = sort(vel(p,:),'descend');
    ind = find(vel(p,order) > velim(2) | vel(p,order) < velim(1));
    vel(p,order(ind)) = NaN;
    
end

% Calculate velocity data
Vmax = max(vel');
Vmin = min(vel');
Vhet = Vmin./Vmax;

% Write file
cHeader = {'VP' 'VS' 'PAni' 'Sani' 'Azimuth' 'Dip' 'Start_year' 'Start_month' ...
    'Start_day' 'Start_hour' 'Start_minute' 'Start_second' 'End_year' ...
    'End_month' 'End_day' 'End_hour' 'End_minute' 'End_second'}; %dummy header
commaHeader = [cHeader;repmat({','},1,numel(cHeader))]; %insert commaas
commaHeader = commaHeader(:)';
textHeader = strjoin(cHeader, ','); %cHeader in text with commas
%write header to file
fid = fopen([testname,'_velocity model.csv'],'w');
fprintf(fid,'%s\n',textHeader);
fclose(fid);
model = [];
model(:,1) = Vmax;
model(:,2) = ones(length(Vmax),1);
model(:,3) = Vhet;
model(:,4) = ones(length(Vmax),1);
model(:,5) = zeros(length(Vmax),1);
model(:,6) = 90.*ones(length(Vmax),1);
model = num2cell(model);

sepsurvey = diff(tempi);
ind = find(sepsurvey > 1e-4)+1;
ind = [1;ind;length(sepsurvey)+2];

index = 0;
modeltime = cell(1,1);
for i = 2:length(ind)
    crows = [ind(i-1):1:ind(i)-1];
    if length(crows)~=size(recloc,1)
        continue
    end
    try
        index = index +1;
        filename = sourcelocs{ind(i)-1,1};
        filename([9,16,20:end]) = '-';
        formatIn = 'yyyymmdd-HHMMSS-fff---------';
        modeltime{index,1} = str2num(filename(1:4));
        modeltime{index,2} = str2num(filename(5:6));
        modeltime{index,3} = str2num(filename(7:8));
        modeltime{index,4} = str2num(filename(10:11));
        modeltime{index,5} = str2num(filename(12:13));
        modeltime{index,6} = str2num(filename(14:15));
    catch
        index = index-1;
        continue
    end
end

for i = 1:index
    
    if i == index
        modeltime{i,7} = modeltime{i,1}+1;
        modeltime{i,8} = modeltime{i,2};
        modeltime{i,9} = modeltime{i,3};
        modeltime{i,10} = modeltime{i,4};
        modeltime{i,11} = modeltime{i,5};
        modeltime{i,12} = modeltime{i,6};
    else
        modeltime{i,7} = modeltime{i+1,1};
        modeltime{i,8} = modeltime{i+1,2};
        modeltime{i,9} = modeltime{i+1,3};
        modeltime{i,10} = modeltime{i+1,4};
        modeltime{i,11} = modeltime{i+1,5};
        modeltime{i,12} = modeltime{i+1,6};
    end
end

model = [model(1:size(modeltime,1),:),modeltime];
ind = find(isnan(cell2mat(model(:,1))) == 1);
model(ind,:) = [];
model{1,7} = model{1,7} - 1;

display('fin')
dlmwrite([testname,'_velocity model.csv'],model,'-append');
save pktimes_survey_ml.mat pktimes; save tempi_survey_ml.mat tempi

