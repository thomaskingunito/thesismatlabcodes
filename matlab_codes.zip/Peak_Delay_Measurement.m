%% Peak Delay Measurement
% Automatically picks the peak delay for the chosen frequency ranges

%% Version
% Version 1.0, 12th February 2019. Thomas King
%   - First Version

%% Parameter customisation
% Below are the suggested parameters to be modified. I don't recommend
% changing any of the code outside of these parameters.

clear all; close all; warning off all

% sourceloc or eventdatamech (0 or 1)
sources = 0; % Loading data from eventdatamech allows to pick for specific types of events e.g. T-type
mechtype = 'fitMM';

% Frequencys. Nx3 matrix, [min, max, mean]
freq(:,1) = [50000;100000;200000;400000];
freq(:,2) = 2.*freq(:,1);
freq(:,3) = round(freq(:,1) + (freq(:,2)-freq(:,1))/2,0);

% Pre-compiles waveform data
compile = 1;

%% Compile data

if compile == 1
    % Load data
    load('recloc.mat');
    load('pktimes_ml.mat')
    load tempi_ml.mat
    load('sourceloc_ml.mat');
    if sources == 1
        load eventdatamech_ml.mat
        
        % Data clearing
        emptyCells = cellfun(@isempty,eventdata(:,14));
        eventdata(emptyCells,:) = [];
        
        % Match sourcelocs to eventdata file list
        ind = [];
        for i = 1:size(sourcelocs,1)
            for j = 1:size(eventdata,1)
                test = strcmp(sourcelocs{i,1},eventdata{j,1});
                if test == 1
                    ind = [ind,i];
                    break
                end
                
            end
        end
        sourcelocs = sourcelocs(ind,:);
        pktimes = pktimes(:,:,ind);
        tempi = tempi(ind);
    end
    
    % Compiles data into matrices
    cd sg2; index = 0;
    for i = 1:size(sourcelocs,1)
        display(num2str(size(sourcelocs,1)-i+1))
        
        % Skip mechanisms you don't want
        if sources == 1 && mean(ismember(eventdata{i,14},mechtype)) ~= 1
            continue
        end
        
        % Load waveform
        [signal,SR] = leggisg2(char(sourcelocs(i,1))); 
        if index == 0; Ts = SR; Fs = 1/SR; end
        
        % Compile 
        for j = 1:size(recloc,1)
                if isempty(pktimes{j,2,i}) == 1 || isnan(pktimes{j,2,i}) == 1
                    continue
                end
                try
                index = index + 1;
                allsig(:,index) = signal(:,j); % waveform data
                rayparam(index,1) = j; % channel
                rayparam(index,2) = pktimes{j,2,i}; % pick time pk(i,n);%
                rayparam(index,3) = norm(cell2mat(sourcelocs(i,2:4)) - recloc(j,:)); % distance
                rayparam(index,4) = sourcelocs{i,5}; % Source time
                rayparam(index,5:7) = cell2mat(sourcelocs(i,2:4)); % Source Location
                rayparam(index,8:10) = recloc(j,:); % Receiver location
                rayparam(index,12) = i; %Event
                rayparam(index,13) = pktimes{j,3,i}; % SNR ratios
                rayparam(index,14) = pktimes{j,4,i};
                rayparam(index,15) = pktimes{j,5,i};
                rayparam(index,16) = pktimes{j,6,i};
                rayparam(index,17) = pktimes{j,7,i};
                catch
                    if index == 1
                        index = 0;
                    else
                    index = index - 1;
                    end
                end
        end
    end
    cd ..
    save peakdelayrays.mat allsig rayparam
else
    load peakdelayrays.mat
end

%% Measure peak delay
indextt = 0; % Clock
for fr = 1:size(freq,1) % Frequency
    for r = 1:size(allsig,2)
        % Set bandpass filter
        if r == 1
            [fsignal,Hd] = bandpass(allsig(:,r),[freq(fr,1) freq(fr,2)],Fs);
        else
            fsignal = filter(Hd,allsig(:,r));
        end
        
        % Clock
        indextt = indextt + 1;
        time = round((indextt/(size(freq,1)*size(allsig,2)))*100,1);
        if indextt == 1
            timemem = time;
        end
        if time > timemem
            display([num2str(time),'%'])
            timemem = time;
        end
        
        % Measurements 
        tt = round(rayparam(r,2)/Ts,0); % arrival time
        sigbck = allsig(:,r); % backup
        efsignal = smooth(envelope(fsignal,round(freq(fr,3)/Fs)+1,'rms'),100); % smoothed envelope
        
        try
            delay = find(efsignal(tt:end) == max(efsignal(tt:end))); % peak delay
            lapseerr(r,fr) = abs(efsignal(delay+tt))./max(abs(efsignal(1:tt))); % error measurement peak-SNR
            lapse(r,fr) = delay*Ts; % Convert to real time
        catch
            lapseerr(r,fr) = NaN;
            lapse(r,fr) = NaN;
        end
    end 
end

save peakdelay_measurements.mat lapse lapseerr freq
